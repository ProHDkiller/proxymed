package com.example.proxymed

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
